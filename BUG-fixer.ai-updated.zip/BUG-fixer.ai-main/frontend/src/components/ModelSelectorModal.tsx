import {
  AlertCircle,
  Check,
  CheckCircle2,
  Cpu,
  Info,
  Layers,
  Loader2,
  Lock,
  X,
} from 'lucide-react';
import React, { useEffect, useState } from 'react';
import { AIModel, fetchModels } from '../api/settings';
import { ApiError } from '../api/client';

interface ModelSelectorModalProps {
  isOpen: boolean;
  onClose: () => void;
  /** id in "provider:model" form, matching AIModel.id */
  currentModel: string;
  onSelectModel: (model: AIModel) => void;
}

const PROVIDER_LABEL: Record<string, string> = {
  groq: 'Groq',
  google: 'Google',
  openrouter: 'OpenRouter',
  anthropic: 'Anthropic',
  openai: 'OpenAI',
  deepseek: 'DeepSeek',
};

export const ModelSelectorModal: React.FC<ModelSelectorModalProps> = ({
  isOpen,
  onClose,
  currentModel,
  onSelectModel,
}) => {
  const [models, setModels] = useState<AIModel[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [filterProvider, setFilterProvider] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    if (!isOpen) return;
    let cancelled = false;
    (async () => {
      setLoading(true);
      setError(null);
      try {
        const data = await fetchModels();
        if (!cancelled) setModels(data);
      } catch (err) {
        if (!cancelled) setError(err instanceof ApiError ? err.message : 'Could not load models.');
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [isOpen]);

  if (!isOpen) return null;

  const providers = ['ALL', ...Array.from(new Set(models.map((m) => m.provider)))];

  const filteredModels = models.filter((m) => {
    const q = searchQuery.toLowerCase();
    const matchesSearch =
      m.name.toLowerCase().includes(q) || m.provider.toLowerCase().includes(q) || m.description.toLowerCase().includes(q);
    const matchesProvider = filterProvider === 'ALL' || m.provider === filterProvider;
    return matchesSearch && matchesProvider;
  });

  const configuredCount = models.filter((m) => m.configured).length;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="w-full max-w-3xl bg-[#0D1117] border border-[#30363D] rounded-xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh] animate-in fade-in zoom-in duration-150 text-[#E2E8F0]">
        {/* Modal Header */}
        <div className="p-5 border-b border-[#30363D] flex items-center justify-between bg-[#161B22]">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-indigo-600 flex items-center justify-center text-white shadow-md shadow-indigo-900/30">
              <Cpu className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold text-white">AI Engine & Model Management</h2>
                <span className="px-2 py-0.5 text-[10px] font-semibold bg-green-500/10 text-green-400 border border-green-500/30 rounded-full">
                  {configuredCount} Connected
                </span>
              </div>
              <p className="text-xs text-gray-400 mt-0.5">
                Switch the active model for Workspace chat, AI diagnosis, and fix generation — applies everywhere.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-gray-400 hover:text-white hover:bg-[#21262D] rounded-lg transition-colors cursor-pointer"
            title="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Filter Toolbar */}
        <div className="p-4 border-b border-[#30363D] bg-[#0B0E14] flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0">
            {providers.map((p) => (
              <button
                key={p}
                onClick={() => setFilterProvider(p)}
                className={`px-3 py-1.5 rounded-md font-medium transition-colors cursor-pointer whitespace-nowrap ${
                  filterProvider === p
                    ? 'bg-indigo-600 text-white shadow-sm'
                    : 'bg-[#161B22] text-gray-400 hover:text-gray-200 border border-[#30363D]'
                }`}
              >
                {p === 'ALL' ? 'ALL' : PROVIDER_LABEL[p] ?? p}
              </button>
            ))}
          </div>

          <div className="relative">
            <input
              type="text"
              placeholder="Search model or capability..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full sm:w-56 px-3 py-1.5 bg-[#161B22] border border-[#30363D] rounded-md text-xs text-gray-200 placeholder-gray-500 focus:outline-none focus:border-indigo-500"
            />
          </div>
        </div>

        {/* Model Cards Grid */}
        <div className="flex-1 overflow-y-auto p-5 space-y-3.5 bg-[#0B0E14]">
          {loading && (
            <div className="flex items-center justify-center gap-2 text-gray-400 text-sm py-10">
              <Loader2 className="w-4 h-4 animate-spin" /> Loading models…
            </div>
          )}

          {error && (
            <div className="flex items-start gap-2 text-sm text-red-400 bg-red-950/30 border border-red-500/30 rounded-md px-3 py-2">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          {!loading &&
            !error &&
            filteredModels.map((model) => {
              const isCurrentlySelected = currentModel === model.id;

              return (
                <div
                  key={model.id}
                  onClick={() => model.configured && onSelectModel(model)}
                  className={`group rounded-lg border p-4 transition-all relative ${
                    !model.configured ? 'opacity-60 cursor-not-allowed' : 'cursor-pointer'
                  } ${
                    isCurrentlySelected
                      ? 'bg-indigo-950/20 border-indigo-500 shadow-md shadow-indigo-950/30'
                      : 'bg-[#0D1117] border-[#30363D] hover:border-gray-500 hover:bg-[#161B22]'
                  }`}
                >
                  <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                    <div className="space-y-2 flex-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <div className="flex items-center gap-1.5">
                          <span
                            className={`w-2.5 h-2.5 rounded-full ${
                              model.configured ? 'bg-green-500 shadow-xs shadow-green-500/50' : 'bg-gray-600'
                            }`}
                          />
                          <h3 className="text-sm font-bold text-white font-mono">{model.name}</h3>
                        </div>

                        <span className="text-[11px] text-gray-400 font-mono">
                          by {PROVIDER_LABEL[model.provider] ?? model.provider}
                        </span>

                        {model.free && (
                          <span className="px-2 py-0.2 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                            Free tier
                          </span>
                        )}

                        {!model.configured && (
                          <span className="px-2 py-0.2 rounded text-[10px] font-bold bg-gray-700/40 text-gray-400 border border-gray-600/40 flex items-center gap-1">
                            <Lock className="w-2.5 h-2.5" /> No API key on server
                          </span>
                        )}

                        {isCurrentlySelected && (
                          <span className="px-2 py-0.2 rounded text-[10px] font-bold bg-green-500/20 text-green-300 border border-green-500/40 flex items-center gap-1">
                            <CheckCircle2 className="w-3 h-3" />
                            ACTIVE ENGINE
                          </span>
                        )}
                      </div>

                      <p className="text-xs text-gray-300 leading-relaxed pr-2">{model.description}</p>

                      <div className="flex flex-wrap items-center gap-2 pt-1">
                        <span className="px-2 py-0.5 rounded bg-[#161B22] border border-[#30363D] text-[11px] text-gray-400 flex items-center gap-1">
                          <Layers className="w-3 h-3 text-indigo-400" />
                          {model.contextWindow}
                        </span>
                      </div>
                    </div>

                    <div className="flex sm:flex-col items-center sm:items-end justify-between sm:justify-start gap-3 shrink-0 pt-2 sm:pt-0 border-t sm:border-t-0 border-[#21262D]">
                      <button
                        disabled={!model.configured}
                        onClick={() => model.configured && onSelectModel(model)}
                        className={`px-3 py-1.5 rounded-md text-xs font-semibold flex items-center gap-1.5 transition-all ${
                          !model.configured
                            ? 'bg-[#21262D] text-gray-600 cursor-not-allowed'
                            : isCurrentlySelected
                              ? 'bg-green-600 text-white shadow-sm cursor-pointer'
                              : 'bg-[#21262D] hover:bg-indigo-600 text-gray-200 hover:text-white border border-[#30363D] cursor-pointer'
                        }`}
                      >
                        {isCurrentlySelected ? (
                          <>
                            <Check className="w-3.5 h-3.5" />
                            <span>Active</span>
                          </>
                        ) : (
                          <span>Select Model</span>
                        )}
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
        </div>

        {/* Modal Footer */}
        <div className="p-4 border-t border-[#30363D] bg-[#161B22] flex items-center justify-between text-xs">
          <div className="flex items-center gap-2 text-gray-400">
            <Info className="w-4 h-4 text-indigo-400" />
            <span>Models without a key need one added to the server's .env before they can be selected.</span>
          </div>

          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-md bg-[#21262D] hover:bg-[#30363D] text-gray-200 font-medium transition-colors cursor-pointer"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
