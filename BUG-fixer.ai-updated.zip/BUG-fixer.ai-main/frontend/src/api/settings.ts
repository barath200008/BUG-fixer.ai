import { apiRequest } from './client';

export interface UserSetting {
  primaryProvider: string;
  primaryModel: string;
  autoRunTests: boolean;
  minimumConfidence: number;
  sandboxGuardrails: boolean;
}

export interface SettingsResponse {
  settings: UserSetting;
  credentials: { provider: string; baseUrl: string | null; createdAt: string }[];
}

export interface AIModel {
  id: string;
  provider: string;
  model: string;
  name: string;
  free: boolean;
  configured: boolean;
  contextWindow: string;
  description: string;
}

export function fetchSettings(): Promise<SettingsResponse> {
  return apiRequest<SettingsResponse>('/settings');
}

export function updateSettings(patch: Partial<UserSetting>): Promise<SettingsResponse> {
  return apiRequest<SettingsResponse>('/settings', { method: 'PATCH', body: patch });
}

export function fetchModels(): Promise<AIModel[]> {
  return apiRequest<AIModel[]>('/settings/models');
}
