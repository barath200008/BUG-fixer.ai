import { env } from '../../../config/env.js';
import { AppError } from '../../../common/errors/AppError.js';
import { prisma } from '../../../config/database.js';
import { encryptSecret, decryptSecret } from '../../../config/security.js';

async function githubRequest(token: string, path: string) {
  const response = await fetch(`${env.GITHUB_API_URL}${path}`, {
    headers: {
      accept: 'application/vnd.github+json',
      authorization: `Bearer ${token}`,
      'x-github-api-version': '2022-11-28',
      'user-agent': 'bugfixai-backend',
    },
  });
  if (!response.ok) throw new AppError(response.status, 'GITHUB_ERROR', `GitHub request failed with status ${response.status}`);
  return response.json();
}

export async function listRepos(token: string) {
  return githubRequest(token, '/user/repos?per_page=100&sort=updated');
}

export async function connectRepository(userId: string, projectId: string, token: string, owner: string, repo: string, branch?: string) {
  const data = await githubRequest(token, `/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}`) as { clone_url?: string; default_branch?: string };
  if (!data.clone_url) throw new AppError(502, 'GITHUB_REPOSITORY_ERROR', 'GitHub did not return a clone URL');
  const project = await prisma.project.findFirst({ where: { id: projectId, ownerId: userId } });
  if (!project) throw new AppError(404, 'PROJECT_NOT_FOUND', 'Project was not found');
  return prisma.project.update({
    where: { id: projectId },
    data: { sourceType: 'GITHUB', repositoryUrl: data.clone_url, defaultBranch: branch ?? data.default_branch ?? 'main' },
  });
}

// --- Token storage (new) ---

export async function saveGithubToken(userId: string, token: string) {
  const encryptedKey = encryptSecret(token);
  await prisma.providerCredential.upsert({
    where: { userId_provider: { userId, provider: 'github' } },
    update: { encryptedKey },
    create: { userId, provider: 'github', encryptedKey },
  });
}

export async function getGithubToken(userId: string): Promise<string | null> {
  const cred = await prisma.providerCredential.findUnique({
    where: { userId_provider: { userId, provider: 'github' } },
  });
  if (!cred) return null;
  return decryptSecret(cred.encryptedKey);
}

export async function hasGithubToken(userId: string): Promise<boolean> {
  const cred = await prisma.providerCredential.findUnique({
    where: { userId_provider: { userId, provider: 'github' } },
  });
  return !!cred;
}