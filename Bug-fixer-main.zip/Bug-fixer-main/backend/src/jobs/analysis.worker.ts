import { Worker } from 'bullmq';
import { redis } from '../config/redis.js';
import { prisma } from '../config/database.js';
import { pipelineDefinitions } from '../modules/analysis/pipeline/phase-manager.js';
import { addLog } from '../modules/analysis/pipeline/pipeline.service.js';
import { RealtimeGateway } from '../common/websocket/realtime.gateway.js';
import { realtimeEvents } from '../common/websocket/events.js';
import { extractArchive } from '../modules/uploads/zip-extractor.js';
import { inspectProject } from '../modules/code-analysis/project-inspector.js';
import { detectBuildCommand } from '../modules/analysis/detectors/build.detector.js';
import { detectTestCommand } from '../modules/analysis/detectors/runtime.detector.js';
import { runSandbox } from '../modules/sandbox/sandbox.service.js';
import { parseGenericTestOutput } from '../modules/errors/test-result-parser.js';
import { recordError } from '../modules/errors/error-collector.service.js';
import { cloneRepository } from '../modules/repositories/git.service.js';
import { getGithubToken } from '../modules/integrations/github/github.service.js';
import path from 'node:path';
import fs from 'node:fs/promises';

export function createAnalysisWorker(gateway: RealtimeGateway) {
  return new Worker(
    'analysis',
    async (job) => {
      const { analysisId, projectId } = job.data as {
        analysisId: string;
        projectId: string;
      };

      const run = await prisma.analysisRun.findUnique({
        where: { id: analysisId },
        include: { phases: true, project: true },
      });

      if (!run) throw new Error('Analysis run not found');

      await prisma.analysisRun.update({
        where: { id: analysisId },
        data: { status: 'RUNNING', startedAt: new Date() },
      });

      gateway.publish(projectId, {
        type: realtimeEvents.analysisStarted,
        projectId,
        analysisId,
        payload: { analysisId },
      });

      const workRoot = path.resolve('sandbox-work', projectId, analysisId);

      try {
        await fs.mkdir(workRoot, { recursive: true });

        for (const definition of pipelineDefinitions) {
          const phase = run.phases.find((p) => p.number === definition.number);
          if (!phase)
            throw new Error(`Missing pipeline phase ${definition.number}`);

          const runningPhase = await prisma.pipelinePhase.update({
            where: { id: phase.id },
            data: { status: 'RUNNING', startedAt: new Date() },
          });

          gateway.publish(projectId, {
            type: realtimeEvents.phaseStarted,
            projectId,
            analysisId,
            payload: runningPhase,
          });

          await addLog(
            gateway,
            analysisId,
            projectId,
            'INFO',
            definition.name,
            `Starting ${definition.name}`,
            phase.id
          );

          // Phase 1: Setup - Extract or clone project source
          if (definition.number === 1) {
            if (run.project.sourceType === 'GITHUB') {
              if (!run.project.repositoryUrl)
                throw new Error(
                  'Repository URL is missing for this GitHub project'
                );
              const token = await getGithubToken(run.project.ownerId);
              if (!token)
                throw new Error(
                  'No GitHub token saved for this account. Connect GitHub first.'
                );
              const authenticatedUrl = run.project.repositoryUrl.replace(
                'https://',
                `https://${token}@`
              );
              await cloneRepository(
                authenticatedUrl,
                workRoot,
                run.project.defaultBranch ?? undefined
              );
            } else {
              if (!run.project.sourcePath)
                throw new Error('Project source archive is missing');
              await extractArchive(run.project.sourcePath, workRoot);
            }

            await prisma.project.update({
              where: { id: projectId },
              data: { workspacePath: workRoot },
            });

            await prisma.workspace.upsert({
              where: { projectId },
              update: { rootPath: workRoot },
              create: { projectId, rootPath: workRoot },
            });
          }

          // Phase 2: Inspect - Detect language and framework
          if (definition.number === 2) {
            const inspection = await inspectProject(workRoot);
            await prisma.project.update({
              where: { id: projectId },
              data: {
                language: inspection.language,
                framework: inspection.framework,
              },
            });
            await addLog(
              gateway,
              analysisId,
              projectId,
              'PASS',
              'Project Setup',
              `Detected ${inspection.language} with ${inspection.framework}`,
              phase.id
            );
          }

          // Phase 4: Build - Run build command
          if (definition.number === 4) {
            const language =
              (
                await prisma.project.findUnique({
                  where: { id: projectId },
                  select: { language: true },
                })
              )?.language ?? 'Unknown';

            const command = await detectBuildCommand(workRoot, language);
            const result = await runSandbox(workRoot, command);

            if (result.code !== 0) {
              await recordError({
                projectId,
                analysisRunId: analysisId,
                name: 'BuildError',
                message: `Build command failed: ${command}`,
                stackTrace: result.stderr,
              });
              throw new Error(`Build failed: ${result.stderr.slice(0, 2000)}`);
            }

            await addLog(
              gateway,
              analysisId,
              projectId,
              'PASS',
              'Install & Build',
              `Build succeeded with ${command}`,
              phase.id
            );
          }

          // Phase 5: Test - Run test command
          if (definition.number === 5) {
            const language =
              (
                await prisma.project.findUnique({
                  where: { id: projectId },
                  select: { language: true },
                })
              )?.language ?? 'Unknown';

            const command = await detectTestCommand(workRoot, language);
            const result = await runSandbox(workRoot, command);

            const summary = parseGenericTestOutput(
              result.stdout,
              result.stderr,
              result.code
            );

            await prisma.testRun.create({
              data: {
                projectId,
                analysisRunId: analysisId,
                command,
                status: summary.status,
                total: summary.total,
                passed: summary.passed,
                failed: summary.failed,
                skipped: summary.skipped,
                durationMs: result.durationMs,
                stdout: result.stdout.slice(0, 100000),
                stderr: result.stderr.slice(0, 100000),
              },
            });

            if (result.code !== 0)
              await recordError({
                projectId,
                analysisRunId: analysisId,
                name: 'TestFailure',
                message: `Test command failed: ${command}`,
                stackTrace: result.stderr,
              });
          }

          const completedPhase = await prisma.pipelinePhase.update({
            where: { id: phase.id },
            data: {
              status: 'COMPLETED',
              completedAt: new Date(),
              durationMs: Date.now() - (phase.startedAt ?? new Date()).getTime(),
            },
          });

          gateway.publish(projectId, {
            type: realtimeEvents.phaseProgress,
            projectId,
            analysisId,
            payload: completedPhase,
          });

          await addLog(
            gateway,
            analysisId,
            projectId,
            'PASS',
            definition.name,
            `${definition.name} completed`,
            phase.id
          );
        }

        await prisma.analysisRun.update({
          where: { id: analysisId },
          data: { status: 'COMPLETED', completedAt: new Date() },
        });

        await prisma.project.update({
          where: { id: projectId },
          data: { status: 'READY' },
        });

        gateway.publish(projectId, {
          type: realtimeEvents.analysisCompleted,
          projectId,
          analysisId,
          payload: { analysisId },
        });
      } catch (error) {
        const message =
          error instanceof Error ? error.message : String(error);
        await prisma.analysisRun.update({
          where: { id: analysisId },
          data: {
            status: 'FAILED',
            completedAt: new Date(),
            errorMessage: message,
          },
        });
        await prisma.project.update({
          where: { id: projectId },
          data: { status: 'FAILED' },
        });
        gateway.publish(projectId, {
          type: realtimeEvents.analysisFailed,
          projectId,
          analysisId,
          payload: { message },
        });
        throw error;
      }
    },
    { connection: redis, concurrency: 2 }
  );
}
